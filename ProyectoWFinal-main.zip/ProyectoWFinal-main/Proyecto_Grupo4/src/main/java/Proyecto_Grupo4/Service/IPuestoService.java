/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Proyecto_Grupo4.Service;

import Proyecto_Grupo4.Entity.puesto;
import java.util.List;

/**
 *
 * @author yulien
 */
public interface IPuestoService {
     public List<puesto>listpuesto();
}
