/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Proyecto_Grupo4.Service;


import Proyecto_Grupo4.Entity.seccion;
import java.util.List;
import org.springframework.stereotype.Service;

/**
 *
 * @author yulien
 */
@Service

public interface ISeccionService {
     public List<seccion>listseccion();
}
