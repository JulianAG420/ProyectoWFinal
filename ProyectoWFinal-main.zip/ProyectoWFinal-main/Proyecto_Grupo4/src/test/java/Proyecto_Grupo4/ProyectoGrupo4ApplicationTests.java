package Proyecto_Grupo4;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProyectoGrupo4ApplicationTests {

	@Test
	void contextLoads() {
	}

}
